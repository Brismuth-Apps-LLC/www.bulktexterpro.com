# Support
If you run into issues, check out the [Bulk Texter Pro FAQ](https://www.bulktexterpro.com/docs/faq). If the FAQ doesn't help, you can also email us at [support@bulktexterpro.com](mailto:support@bulktexterpro.com).

Occasionally, Google may make changes to Google Voice that stop Bulk Texter Pro from functioning correctly. When this happens, we will update Bulk Texter Pro to support the new changes as quickly as possible. You may be required to manually re-install a new version of Bulk Texter Pro.

# Terms of Use
By using this software, you agree that you understand and will abide by the following terms:
* You will not use this software to facilitate any illegal activity.
* You will not resell or share this software with others.
* You use Bulk Texter Pro at your own risk. Brismuth Apps, LLC and Bulk Texter Pro are not affiliated with Google or Google Voice. We are not responsible for any action Google may take in response to your usage of Bulk Texter Pro. Google has on occasion banned accounts that it decided were violating its Terms of Service.
* You acknowledge that as the user you are solely responsible for compliance with the Telephone Consumer Protection Act and “Do Not Call” legislation, as well as any other applicable legislation governing the collection, management, and use of consumer telephone numbers.

# Privacy Policy
Your email address is collected as part of registration via [extensionpay.com](https://extensionpay.com/). Your credit card information is only shared with [Stripe](https://stripe.com/). None of your data is sold or shared with other 3rd parties.
We do not collect any data about your text messages, contacts, or software usage. Messages that you schedule to be sent, including corresponding phone numbers, are only stored locally on your device.

# License Agreement
This software is licensed for use only by the original purchaser. It is to be used only with the Google Voice email address that corresponds to your registration/purchase. The software will only function with Google Voice accounts that match the registered email address.

This software is not for resale, and the license is not transferrable.

You may cancel your subscription at any time by clicking "Manage Subscription" inside Bulk Texter Pro.

# Computer setup for reliable scheduling
To be certain that scheduled messages are sent on time, you must configure your computer to not go to sleep/hibernate/shut down.

See the [installation guide](https://www.bulktexterpro.com/docs/getting-started/installing-it#setting-up-your-computer-for-scheduled-messages) for some tips.