// Microsoft Edge compatibility
if (chrome == null) {
	chrome = browser;
}

function showVersionNumber() {
	const manifest = chrome.runtime.getManifest();
	document.getElementById('version-number').innerText = `v${manifest.version}`;
}

// configure popup button event listener
document.addEventListener('DOMContentLoaded', () => {
	showVersionNumber();
});
